# coding=utf-8
configs = {
    'db': {
        'database': 'awesome'
    }
}